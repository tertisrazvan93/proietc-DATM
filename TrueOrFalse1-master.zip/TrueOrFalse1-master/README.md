# TrueOrFalse1

This github project is app store ready. All you have to do is supply your own images and questions.
